package com.zte.sunquan.demo.model;

/**
 * Hobby class
 *
 * @author 10184538
 * @date 2019/4/12
 */
public class Hobby {
    private String pId;
    private String id;
    private String name;
    private String love;

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLove() {
        return love;
    }

    public void setLove(String love) {
        this.love = love;
    }
}
