package com.zte.sunquan.demo.model;

/**
 * Vehicle class
 *
 * @author 10184538
 * @date 2019/4/13
 */
public interface Vehicle {
    String getUserId();
}
