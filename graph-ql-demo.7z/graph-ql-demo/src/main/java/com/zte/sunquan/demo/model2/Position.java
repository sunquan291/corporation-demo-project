package com.zte.sunquan.demo.model2;

/**
 * Position class
 *
 * @author 10184538
 * @date 2019/4/9
 */
public enum Position {
    HIGH,
    LOW,
    MIDDLE
}
