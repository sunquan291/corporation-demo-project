package com.zte.sunquan.demo.model2;

/**
 * Animal class
 *
 * @author 10184538
 * @date 2019/6/14
 */
public interface Animal {
}
