package com.zte.sunquan.demo.model;

/**
 * Created by james on 6/7/17.
 * 为演示GraphQL interface创建的接口
 *
 * blog: www.zhaiqianfeng.com
 */
public interface IAnimal {
    String getName();
}
